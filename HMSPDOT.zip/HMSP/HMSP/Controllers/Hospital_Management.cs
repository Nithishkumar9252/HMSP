﻿using HMSP.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HMSP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Hospital_Management : ControllerBase
    {
        private readonly appointment _appointment;

        public Hospital_Management(appointment appointment)
        {
            _appointment = appointment;
        }
        /// <summary>
        /// USER SIGN UP 
        /// </summary>

        usersignupRep obj =new usersignupRep();
        [HttpPost]
        [Route("SignUp")]
        public int generate([FromBody] usersignup model)
        {
            return obj.addentry(model);
        }


        /// <summary>
        /// USER LOGIN
        /// </summary>
        userloginRep obj1 = new userloginRep();
        [HttpPost]
        [Route("Login")]
        public ActionResult loginadd(userlogin model)
        {
            return Ok(obj1.userlogins(model));
        }


        /// <summary>
        /// ADMIN SIGN UP
        /// </summary>
        adminsignupRep obj2 = new adminsignupRep();
        [HttpPost]
        [Route("Admin_SignUp")]
        public int admin_generate([FromBody] adminsignup model)
        {
            return obj2.addadminentry(model);
        }


        /// <summary>
        /// ADMIN LOGIN
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost("Admin_Login")]
        public IActionResult AdminLoginadd(adminlogin model)
        {
            var adminResp = new adminloginRep();
            var result = adminResp.adminlogins(model);

            if (result == "locked")
            {
                return StatusCode(401, "Account is locked.");
            }
            else if (result == "Incorrect")
            {
                return BadRequest("Incorrect username or password.");
            }
            else
            {
                return Ok(new { token = result });
            }
        }



        /// <summary>
        /// ADD DOCTOR
        /// </summary>
        addDoctorRep obj3 = new addDoctorRep();
        [HttpPost]
        [Route("AddDoctor")]
        public int generate_addDoctor([FromBody] doctor rep)
        {
            return obj3.adddoctorentry(rep);
        }


        /// <summary>
        /// DELETE DOCTOR
        /// </summary>
        /// 
        deleteDoctorRep obj4 = new deleteDoctorRep();
        [HttpDelete("api/users/delete/{doctorID}")]
        public string delete_doctor(int doctorID)

        {

            return obj4.Delete(doctorID);
        }

        /// <summary>
        /// Get Doctor By ID
        /// </summary>
        /// 
        GetDoctorById obj5= new GetDoctorById();
        [HttpGet]
        [Route("api/doctor/{id}")]
        public IEnumerable<doctor> getDoctorById(int id)
        {
            return obj5.GetDoctorBy_Id(id);
        }

        /// <summary>
        /// Display All Doctors
        /// </summary>
        DisplayAllDoctor obj8 = new DisplayAllDoctor();
        [HttpGet]
        [Route("api/doctor/")]
        public IEnumerable<doctor> GetProduct()
        {
            return obj8.GetProducts();
        }




        //appointment objnew1 = new appointment();

        //[HttpPost]
        //[Route("api/users/booking")]
        //public ActionResult bookings(bookings model)
        //{
        //    return Ok(objnew1.booking(model));
        //}

        /// <summary>
        /// Add Booking
        /// </summary>
        /// <param name="PatientID"></param>
        /// <param name="DoctorID"></param>
        /// <param name="CheckInDate"></param>
        /// <param name="TimeSlot"></param>
        /// <returns></returns>

        [HttpPost("BookAppointment")]
        public IActionResult BookAppointment(int PatientID, int DoctorID, string CheckInDate, string TimeSlot)
        {
            int result = _appointment.booking(PatientID, DoctorID, CheckInDate, TimeSlot);

            if (result == 0)
            {
                return BadRequest("The selected time slot is already booked.");
            }
            else if (result == 1)
            {
                return Ok("Appointment booked successfully.");
            }
            else
            {
                return StatusCode(500, "An unexpected error occurred.");
            }
        }

        /// <summary>
        /// Delete Booking
        /// </summary>
        deletebooking obj6= new deletebooking();
        [HttpDelete("api/users/deleteBookings/{bookingID}")]
        public string DeleteBookings(int bookingID)
        {
            return obj6.DeleteBookings(bookingID);
        }



        //bookslotRep obj7=new bookslotRep();

        //[HttpGet("api/slot/{CheckInDate}/{DoctorID}")]
        //public List<string> bookSlot(string CheckInDate, int DoctorID)
        //{
        //    return obj7.bookSlots(CheckInDate, DoctorID);
        //}


       


        /// <summary>
        /// Display Bookings By ID
        /// </summary>
        displayBookingById obj9= new displayBookingById();
        [HttpGet]
        [Route("api/admin/displaybooking/{PatientID}")]
        public List<booking> GetLists(int PatientID)
        {
            return obj9.GetList(PatientID);
        }


        /// <summary>
        /// Display All Bookings
        /// </summary>
        DisplayAllBookings obj10= new DisplayAllBookings();
        [HttpGet]
        [Route("api/admin/displaytotalbooking")]
        public List<totalBookings> GetFullList()
        {
            return obj10.GetFullList();
        }

        //addDoctorRep obj3 = new addDoctorRep();
        //[HttpPost]
        //[Route("AddDoctor")]
        //public int doctorlogin([FromBody] adddoctor model)
        //{
        //    return obj3.adddoctorentry(model);
        //}


        //public addDoctorRep AddDoctorRep { get; set; }

        //[HttpPost("AddDoctor")]
        //public IActionResult AddDoctor(adddoctor model)
        //{
        //    try
        //    {
        //        if (AddDoctorRep == null)
        //        {
        //            return StatusCode(500, "addDoctorRep dependency is not initialized.");
        //        }

        //        int result = AddDoctorRep.adddoctorentry(model);

        //        if (result == 1)
        //        {
        //            return Ok("Doctor entry added successfully.");
        //        }
        //        else
        //        {
        //            return StatusCode(500, "Failed to add doctor entry.");
        //        }
        //    }
        //    catch
        //    {
        //        return StatusCode(500, "An unexpected error occurred while adding doctor entry.");
        //    }
        //}


        //[HttpPost("DoctorLogin")]
        //public IActionResult VerifyLogin(string username, string password)
        //{
        //    var result = _doctorLoginRep.VerifyDoctorLogin(username, password);

        //    if (result == null)
        //    {
        //        return StatusCode(500, "An unexpected error occurred.");
        //    }
        //    else if (result == "success")
        //    {
        //        return Ok("Login successful.");
        //    }
        //    else if (result == "Incorrect")
        //    {
        //        return BadRequest("Incorrect username or password.");
        //    }
        //    else if (result == "locked")
        //    {
        //        return StatusCode(401, "Account is locked.");
        //    }
        //    else
        //    {
        //        return StatusCode(500, "An unexpected error occurred.");
        //    }
        //}

        // adminloginRep obj3=new adminloginRep();
        // [HttpPost]
        // [Route("Admin_Login")]
        //public int adminloginadd(adminlogin model)
        // {
        //     return Ok(obj3.adminlogins(model));
        // }


        //[HttpPost("Login")]
        //public IActionResult Login(adminlogin model)
        //{
        //    try
        //    {
        //        var adminResp = new adminloginRep();
        //        var result = adminResp.adminlogins(model);

        //        if (result == "locked")
        //        {
        //            return StatusCode(401, "Account is locked.");
        //        }
        //        else if (result == "Incorrect")
        //        {
        //            return BadRequest("Incorrect username or password.");
        //        }
        //        else
        //        {
        //            return Ok(new { token = result });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"An error occurred: {ex.Message}");
        //    }
        //}
    }
}
