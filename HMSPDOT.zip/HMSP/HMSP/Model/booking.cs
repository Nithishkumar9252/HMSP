﻿namespace HMSP.Model
{
    public class booking
    {
        public string PatientName { get; set; }
        public string DoctorName { get; set; }
        public string AppointmentDate { get; set; }
        public string TimeSlot { get; set; }
        public int bookingID { get; set; }
    }
}
