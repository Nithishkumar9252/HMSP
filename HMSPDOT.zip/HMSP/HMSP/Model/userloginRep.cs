﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace HMSP.Model
{
    public class userloginRep
    {
        public string userlogins(userlogin model)
        {
            try
            {
                string connectionString = "Server=IN3339418W1;Database=HMSP;Trusted_Connection=SSPI;Encrypt=false;TrustServerCertificate=true";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("verify_User", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("@User_Name", SqlDbType.VarChar, 20).Value = model.username;
                    command.Parameters.Add("@Password", SqlDbType.VarChar, 20).Value = model.password;
                    command.Parameters.Add("@Failed_Attempts", SqlDbType.Int).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@Is_Locked", SqlDbType.Bit).Direction = ParameterDirection.Output;

                    SqlParameter returnValueParam = new SqlParameter("@ReturnValue", SqlDbType.Int);
                    returnValueParam.Direction = ParameterDirection.ReturnValue;
                    command.Parameters.Add(returnValueParam);

                    connection.Open();
                    command.ExecuteNonQuery();

                    int userId = (int)returnValueParam.Value;
                    bool isLocked = Convert.ToBoolean(command.Parameters["@Is_Locked"].Value);
                    int failedAttempts = Convert.ToInt32(command.Parameters["@Failed_Attempts"].Value);

                    if (userId == 0)
                    {
                        if (isLocked)
                            return "locked";
                        else
                            return "Incorrect PassWord or Username";
                    }

                    return GenerateJwtToken(userId, model.username);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        private string GenerateJwtToken(int userId, string username)
        {
            string key = "MNU661B13T5rh6H52169abcdefghijklmnop";
            string duration = "60";

            var symmetricKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credentials = new SigningCredentials(symmetricKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim("id", userId.ToString()),
                new Claim("username", username)
            };

            var jwtToken = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToInt32(duration)),
                signingCredentials: credentials
            );

            string token = new JwtSecurityTokenHandler().WriteToken(jwtToken);

            return token;
        }
    }
}
