﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace HMSP.Model
{
    public class deletebooking
    {
        public string DeleteBookings(int bookingID)
        {
            // Create a new SqlConnection object with your connection string
            string constr = "Server = IN3339418W1; Database = HMSP; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            using (SqlConnection connection = new SqlConnection(constr))
            {
                // Create a SQL command that calls the DeleteDoctorAndBookings stored procedure
                SqlCommand command = new SqlCommand("delete_booking", connection);
                command.CommandType = CommandType.StoredProcedure;
                // Add the DoctorId parameter to the command
                command.Parameters.AddWithValue("@bookingID", bookingID);


                // Open the connection
                connection.Open();

                // Execute the command
                command.ExecuteNonQuery();

                // Return HTTP 200 (OK) response
                return "1";

            }
        }
    }
}
