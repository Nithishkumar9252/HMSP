﻿namespace HMSP.Model
{
    public class doctor
    {
    
        public string name { get; set; }
        public string _description { get; set; }
        public string speciality { get; set; }
    }
}
