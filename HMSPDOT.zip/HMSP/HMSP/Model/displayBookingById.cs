﻿using Microsoft.Data.SqlClient;

namespace HMSP.Model
{
    public class displayBookingById
    {
        public List<booking> GetList(int PatientID)
        {
            string constr = "Server = IN3339418W1; Database = HMSP; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            // Create a connection to the database
            List<booking> bookings = new List<booking>();
            using (SqlConnection connection = new SqlConnection(constr))
            using (SqlCommand command = new SqlCommand("GetBookingDetails", connection))
            {
                // Set command type to stored procedure
                command.CommandType = System.Data.CommandType.StoredProcedure;

                // Add parameter for patient ID
                command.Parameters.Add(new SqlParameter("@PatientID", PatientID));

                // Open connection and execute command
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Read results and print them to the console
                while (reader.Read())
                {
                    booking b = new booking();
                    b.PatientName = (string)reader["PatientName"];
                    b.DoctorName = (string)reader["DoctorName"];
                    b.AppointmentDate = (string)reader["AppointmentDate"];
                    b.TimeSlot = (string)reader["TimeSlot"];
                    b.bookingID = Convert.ToInt32(reader["bookingID"]);
                    bookings.Add(b);
                }
                reader.Close();
                connection.Close();

                return bookings;
            }
        }
    }
}
