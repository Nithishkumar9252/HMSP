﻿using Microsoft.Data.SqlClient;

namespace HMSP.Model
{
    public class DisplayAllBookings
    {
        public List<totalBookings> GetFullList()
        {
            string connectionString = "Server = IN3339418W1; Database = HMSP; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            // Create a connection to the database
            List<totalBookings> bookings = new List<totalBookings>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand("totalbookings", connection))
            {
                // Set command type to stored procedure
                command.CommandType = System.Data.CommandType.StoredProcedure;

                // Add parameter for patient ID

                // Open connection and execute command
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Read results and print them to the console
                while (reader.Read())
                {
                    totalBookings b = new totalBookings();
                    b.PatientName = (string)reader["PatientName"];
                    b.DoctorName = (string)reader["DoctorName"];
                    b.AppointmentDate = (string)reader["CheckInDate"];
                    b.TimeSlot = (string)reader["TimeSlot"];
                    b.bookingID = Convert.ToInt32(reader["BookingID"]);
                    b.PatientID = Convert.ToInt32(reader["PatientID"]);
                    bookings.Add(b);
                }
                reader.Close();
                connection.Close();

                return bookings;
            }
        }
    }
}
