﻿using System.Data;
using Microsoft.Data.SqlClient;

namespace HMSP.Model
{
    public class usersignupRep
    {
        public int addentry(usersignup model)
        {
            try
            {
                string constr = "Server = IN3339418W1; Database = HMSP; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
                using (SqlConnection connection = new SqlConnection(constr))
                {

                    SqlCommand cmd = new SqlCommand("Insert_Patient_Details", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@FirstName", model.firstname);
                    cmd.Parameters.AddWithValue("@LastName", model.lastname);
                    cmd.Parameters.AddWithValue("@Age", model.age);
                    cmd.Parameters.AddWithValue("@Gender", model.gender);
                    cmd.Parameters.AddWithValue("@Blood_Group", model.bloodgroup);
                    cmd.Parameters.AddWithValue("@Phone", model.phone);
                    cmd.Parameters.AddWithValue("@Address", model.address);
                    cmd.Parameters.AddWithValue("@email", model.email);
                    cmd.Parameters.AddWithValue("@User_Name", model.username);
                    cmd.Parameters.AddWithValue("@Password", model.password);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                return 1;
            }
            catch
            {
                throw;
            }
        }
    }
}
