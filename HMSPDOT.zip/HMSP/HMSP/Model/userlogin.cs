﻿namespace HMSP.Model
{
    public class userlogin
    {
        public string username { get; set; }
        public string password { get; set; }
    }
}
