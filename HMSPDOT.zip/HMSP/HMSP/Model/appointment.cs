﻿using Microsoft.Data.SqlClient;

namespace HMSP.Model
{
    public class appointment
    {
        public int booking(int PatientID, int DoctorID,string CheckInDate,string TimeSlot)
        {


            string connectionString = "Server = IN3339418W1; Database = HMSP; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";

            // Create a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the connection
                connection.Open();

                List<string> timeSlots = new List<string>();

                SqlCommand cmd = new SqlCommand("Select TimeSlot from Bookings where CheckInDate=@CheckInDate AND TimeSlot=@TimeSlot AND id=@DoctorID", connection);
                cmd.Parameters.AddWithValue("@CheckInDate", CheckInDate);
                cmd.Parameters.AddWithValue("@TimeSlot", TimeSlot);
                cmd.Parameters.AddWithValue("@DoctorID", DoctorID);
                int count = 0;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        count += 1;
                        string timeSlot = reader["TimeSlot"].ToString();
                        timeSlots.Add(timeSlot);
                    }
                }
                if (count >= 1)
                {
                    connection.Close();
                    return (0);
                }
                else
                {

                    // Create a SQL command to insert the booking
                    SqlCommand command = new SqlCommand("INSERT INTO Bookings (PatientID, id, CheckInDate,TimeSlot) VALUES (@UserID, @DoctorID, @CheckInDate,@TimeSlot)", connection);



                    // Set the parameter values from the form data
                    command.Parameters.AddWithValue("@UserID", PatientID);
                    command.Parameters.AddWithValue("@DoctorID", DoctorID);
                    command.Parameters.AddWithValue("@CheckInDate", CheckInDate);
                    command.Parameters.AddWithValue("@TimeSlot", TimeSlot);


                    // Execute the SQL command to insert the booking
                    command.ExecuteNonQuery();
                    connection.Close();
                    return (1);
                }

            }

        }
    }
}
