﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace HMSP.Model
{
    public class addDoctorRep
    {
        string constr = "Server = IN3339418W1; Database = HMSP; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
        public int adddoctorentry(doctor model)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("Insert_Doctor_Details_Info", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Name", model.name);

                    cmd.Parameters.AddWithValue("@description", model._description);
                    cmd.Parameters.AddWithValue("@speciality", model.speciality);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                return 1;
            }
            catch
            {
                throw;
            }
        }
    }
}
