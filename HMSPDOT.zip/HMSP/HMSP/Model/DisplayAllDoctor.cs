﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace HMSP.Model
{
    public class DisplayAllDoctor
    {
        public IEnumerable<doctor> GetProducts()
        {
            string constr = "Server = IN3339418W1; Database = HMSP; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            List<doctor> products = new List<doctor>();

            using (SqlConnection connection = new SqlConnection(constr))
            {
                SqlCommand command = new SqlCommand("select_all_doctors", connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    doctor product = new doctor()
                    {
                        
                        name = reader["name"].ToString(),
                        speciality = reader["speciality"].ToString(),
                        _description = reader["_description"].ToString()
                    };
                    products.Add(product);
                }
                reader.Close();
            }
            return products;
        }
    }
}
