﻿namespace HMSP.Model
{
    public class usersignup
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
        public int age { get; set; }
        public string gender { get; set; }
        public string bloodgroup { get; set; }
        public string phone { get; set; }
        public string address { get; set; }
        public string email { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}
