﻿namespace HMSP.Model
{
    public class bookings
    {
       
        public int PatientID { get; set; }
        public int DoctorID { get; set; }
        public string CheckInDate { get; set; }
        public string TimeSlot { get; set; }
    }
}
