﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Hospital_Management.Models
{
    public class UserRepository
    {
        public async Task<int?> SignUpOrLoginAsync(string firstName, string lastName, int age, string gender, string bloodGroup, string phone, string address, string email, string userName, string password, string action)
        {

            try
            {
                string connectionString = "Server=IN3339418W1;Database=Hospital_Management;Trusted_Connection=SSPI;Encrypt=false;TrustServerCertificate=true";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    await connection.OpenAsync();
                    SqlCommand command = new SqlCommand("User_SignUpOrLogin", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@Age", age);
                    command.Parameters.AddWithValue("@Gender", gender);
                    command.Parameters.AddWithValue("@Blood_Group", bloodGroup);
                    command.Parameters.AddWithValue("@Phone", phone);
                    command.Parameters.AddWithValue("@Address", address);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@User_Name", userName);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Action", action);

                    // Output parameter
                    var outputParameter = new SqlParameter("@PatientId", System.Data.SqlDbType.Int);
                    outputParameter.Direction = System.Data.ParameterDirection.Output;
                    command.Parameters.Add(outputParameter);

                    await command.ExecuteNonQueryAsync();

                    if (int.TryParse(outputParameter.Value.ToString(), out int patientId))
                    {
                        return patientId;
                    }
                    else
                    {
                        return null;
                    }
                }
            
            }
            catch (Exception ex)
            {
                // Handle exception
                Console.WriteLine(ex.Message);
                return null;
            }
        }

      
    }
}
