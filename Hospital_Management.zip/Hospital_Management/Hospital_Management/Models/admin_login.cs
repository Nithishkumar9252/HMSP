﻿using System.Data;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Data.SqlClient;

namespace Hospital_Management.Models
{
    public class admin_login
    {

        public int VerifyUserLogin(userlogin model, out int userId, out int failedAttempts, out bool isLocked)
        {
            userId = 0;
            failedAttempts = 0;
            isLocked = false;
            string constr = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            
                using (SqlConnection conn = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("verify_User_Login", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@User_Name", SqlDbType.VarChar, 20).Value = model.username;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 20).Value = model.password;
                    cmd.Parameters.Add("@Failed_Attempts", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.Parameters.Add("@Is_Locked", SqlDbType.Bit).Direction = ParameterDirection.Output;

                    conn.Open();
                    userId = Convert.ToInt32(cmd.ExecuteScalar());
                    failedAttempts = Convert.ToInt32(cmd.Parameters["@Failed_Attempts"].Value);
                    isLocked = Convert.ToBoolean(cmd.Parameters["@Is_Locked"].Value);
                }




                return userId;
            
        }

        }
}
           
    

