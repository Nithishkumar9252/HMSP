﻿namespace Hospital_Management.Models
{
    public class doctorsignup
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Phone { get; set; }
        public string Email { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public int DoctorID { get; set; }
    }
}
