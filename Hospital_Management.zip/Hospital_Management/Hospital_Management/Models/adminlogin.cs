﻿namespace Hospital_Management.Models
{
    public class adminlogin
    {
        
        public string Username { get; set; }
        public string password { get; set; }
       
    }
}
