﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Hospital_Management.Models
{
    public class doctorsignupResp
    {
        string constr = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
        public int adddoctorentry(doctorsignup model)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("Insert_Doctor_Details_Signup", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@FirstName", model.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", model.LastName);
                    cmd.Parameters.AddWithValue("@Phone", model.Phone);
                    cmd.Parameters.AddWithValue("@Email", model.Email);
                    cmd.Parameters.AddWithValue("@User_Name", model.username);
                    cmd.Parameters.AddWithValue("@Password", model.password);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                return 1;
            }
            catch
            {
                throw;
            }
        }

        
    }
}
