﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Hospital_Management.Models
{
    public class doctordeleteResp
    {
        public string Delete(int doctorId)
        {
            // Create a new SqlConnection object with your connection string
            string connectionString = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Create a SQL command that calls the DeleteDoctorAndBookings stored procedure
                SqlCommand command = new SqlCommand("DeleteDoctorAndBookings", connection);
                command.CommandType = CommandType.StoredProcedure;

                // Add the DoctorId parameter to the command
                command.Parameters.AddWithValue("@DoctorId", doctorId);

                try
                {
                    // Open the connection
                    connection.Open();

                    // Execute the command
                    command.ExecuteNonQuery();

                    // Return HTTP 200 (OK) response
                    return "1";
                }
                catch (Exception ex)
                {
                    // Return HTTP 500 (Internal Server Error) response with the error message
                    return "0";
                }
            }
        }
    }
}
