﻿namespace Hospital_Management.Models
{
    public class total_bookings
    {
        public string PatientName { get; set; }
        public string DoctorName { get; set; }
        public string AppointmentDate { get; set; }
        public string TimeSlot { get; set; }
        public int bookingID { get; set; }
        public int PatientID { get; set; }
    }
}
