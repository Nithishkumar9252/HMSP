﻿namespace Hospital_Management.Models
{
    public class doctorlogin
    {
        public int DoctorID { get; set; }
        public string Username { get; set; }
        public string Pass_word { get; set; }
        public DateTime? LastLogin { get; set; }
        public int FailedAttempts { get; set; }
        public bool IsLocked { get; set; }
    }
}
