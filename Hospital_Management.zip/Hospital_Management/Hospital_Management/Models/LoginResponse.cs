﻿namespace Hospital_Management.Models
{
    public class LoginResponse
    {
        public string LoginId { get; set; }
        public string username { get; set; }
    }
}
