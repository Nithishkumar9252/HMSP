﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Hospital_Management.Models
{
    public class bookslotResp
    {
        public List<string> bookSlots(string CheckInDate, int DoctorID)
        {
            // Create a new SqlConnection object with your connection string
            string connectionString = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            SqlConnection connection = new SqlConnection(connectionString);

            // Create a SQL command that selects all time slots for the given CheckInDate and DoctorID

            SqlCommand command = new SqlCommand("verify_date", connection);
            command.CommandType = CommandType.StoredProcedure;
            // Add the CheckInDate and DoctorID parameters to the command
            command.Parameters.AddWithValue("@CheckInDate", CheckInDate);
            command.Parameters.AddWithValue("@DoctorID", DoctorID);


            // Open the connection
            connection.Open();

            // Execute the command and get a SqlDataReader
            SqlDataReader reader = command.ExecuteReader();

            // Create a list to hold the time slots
            List<string> timeSlots = new List<string>();

            // Read through the SqlDataReader and add each time slot to the list



            while (reader.Read())
            {
                string timeSlot = reader["TimeSlot"].ToString();
                timeSlots.Add(timeSlot);
            }

            // Close the reader and the connection
            reader.Close();
            connection.Close();

            // Return HTTP 200 (OK) response with the list of time slots as the response body
            return timeSlots;

        }
    }
}
