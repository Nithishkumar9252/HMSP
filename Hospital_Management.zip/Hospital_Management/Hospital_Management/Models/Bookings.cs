﻿namespace Hospital_Management.Models
{
    public class Bookings
    {
        public int BookingID { get; set; }
        public int PatientID { get; set; }
        public int DoctorID { get; set; }
        public string CheckInDate { get; set; }
        public string TimeSlot { get; set; }

    }
}
