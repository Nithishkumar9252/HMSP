﻿using Microsoft.Data.SqlClient;

namespace Hospital_Management.Models
{
    public class appointmentResp
    {

        public int booking(Bookings book)
        {



            string connectionString = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";

         
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
          
                connection.Open();
             






                List<string> timeSlots = new List<string>();

                SqlCommand cmd = new SqlCommand("Select TimeSlot from Bookings where CheckInDate=@CheckInDate AND TimeSlot=@TimeSlot AND DoctorID=@DoctorID", connection);
                cmd.Parameters.AddWithValue("@CheckInDate", book.CheckInDate);
                cmd.Parameters.AddWithValue("@TimeSlot", book.TimeSlot);
                cmd.Parameters.AddWithValue("@DoctorID", book.DoctorID);
                int count = 0;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        count += 1;
                        string timeSlot = reader["TimeSlot"].ToString();
                        timeSlots.Add(timeSlot);
                    }
                }
                if (count >= 1)
                {
                    connection.Close();
                    return (0);
                }
                else
                {

                    // Create a SQL command to insert the booking
                    SqlCommand command = new SqlCommand("INSERT INTO Bookings (PatientID, DoctorID, CheckInDate,TimeSlot) VALUES (@UserID, @DoctorID, @CheckInDate,@TimeSlot)", connection);



                    // Set the parameter values from the form data
                    command.Parameters.AddWithValue("@UserID", book.PatientID);
                    command.Parameters.AddWithValue("@DoctorID", book.DoctorID);
                    command.Parameters.AddWithValue("@CheckInDate", book.CheckInDate);
                    command.Parameters.AddWithValue("@TimeSlot", book.TimeSlot);


                    // Execute the SQL command to insert the booking
                    command.ExecuteNonQuery();
                    connection.Close();
                    return (1);
                }








            }

            // Close the connection

        }

    }
}
