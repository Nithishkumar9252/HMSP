﻿//using Microsoft.Data.SqlClient;
//using Microsoft.IdentityModel.Tokens;
//using System.Data;
//using System.IdentityModel.Tokens.Jwt;
//using System.Security.Claims;
//using System.Text;

//namespace Hospital_Management.Models
//{
//    public class userloginResp
//    {
//        public string userlogins(userlogin model)
//        {

//            try
//            {
//                string constr = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
//                using (SqlConnection conn = new SqlConnection(constr))
//                {

//                    SqlCommand cmd = new SqlCommand("verify_User", conn);
//                    cmd.CommandType = CommandType.StoredProcedure;

//                    cmd.Parameters.AddWithValue("@User_Name", model.username);
//                    cmd.Parameters.AddWithValue("@Password", model.password);

//                    cmd.Parameters.AddWithValue("@Failed_Attempts", SqlDbType.Int).Direction = ParameterDirection.Output;
//                    cmd.Parameters.AddWithValue("@Is_Locked", SqlDbType.Bit).Direction = ParameterDirection.Output;

//                    SqlParameter p = new SqlParameter();
//                    p.DbType = System.Data.DbType.Int32;
//                    p.Direction = System.Data.ParameterDirection.ReturnValue;
//                    cmd.Parameters.Add(p);
//                    conn.Open();
//                    cmd.ExecuteNonQuery();

//                    int _PatientId = (int)p.Value;

//                    bool isLocked = Convert.ToBoolean(cmd.Parameters["@Is_Locked"].Value);

//                    int failedAttempts = Convert.ToInt32(cmd.Parameters["@Failed_Attempts"].Value);

//                    if (_PatientId == 0)

//                    {
//                        if (isLocked)

//                        {
//                            return ("locked");
//                        }
//                        else
//                        {
//                            return ("Incorrect");
//                        }
//                    }
//                    var a = _PatientId.ToString();
//                    return (jwtoken(_PatientId, model.username));

//                }
//            }
//            catch
//            {
//                throw;
//            }
//        }
//        public string jwtoken(int LoginID, string username)
//        {
//            LoginResponse response = new LoginResponse();


//            string key = "MNU661B13T5rh6H52169";
//            string duration = "60";



//            var symmetrickey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
//            var credential = new SigningCredentials(symmetrickey, SecurityAlgorithms.HmacSha256);



//            var claims = new[]  {
//                             new Claim("id",LoginID.ToString()),
//                             new Claim("username",username.ToString()),

//                             };



//            var jwtToken = new JwtSecurityToken(
//            issuer: "localhost",
//            audience: "localhost",
//            claims: claims,
//            expires: DateTime.Now.AddMinutes(Int32.Parse(duration)),
//            signingCredentials: credential);




//            string a = new JwtSecurityTokenHandler().WriteToken(jwtToken);



//            return a;



//        }
//    }
//}

using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Hospital_Management.Models
{
    public class userloginResp
    {
        public string userlogins(userlogin model)
        {
            try
            {
                string connectionString = "Server=IN3339418W1;Database=Hospital_Management;Trusted_Connection=SSPI;Encrypt=false;TrustServerCertificate=true";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand("verify_User", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add("@User_Name", SqlDbType.VarChar, 20).Value = model.username;
                    command.Parameters.Add("@Password", SqlDbType.VarChar, 20).Value = model.password;
                    command.Parameters.Add("@Failed_Attempts", SqlDbType.Int).Direction = ParameterDirection.Output;
                    command.Parameters.Add("@Is_Locked", SqlDbType.Bit).Direction = ParameterDirection.Output;

                    SqlParameter returnValueParam = new SqlParameter("@ReturnValue", SqlDbType.Int);
                    returnValueParam.Direction = ParameterDirection.ReturnValue;
                    command.Parameters.Add(returnValueParam);

                    connection.Open();
                    command.ExecuteNonQuery();

                    int userId = (int)returnValueParam.Value;
                    bool isLocked = Convert.ToBoolean(command.Parameters["@Is_Locked"].Value);
                    int failedAttempts = Convert.ToInt32(command.Parameters["@Failed_Attempts"].Value);

                    if (userId == 0)
                    {
                        if (isLocked)
                            return "locked";
                        else
                            return "Incorrect";
                    }

                    return GenerateJwtToken(userId, model.username);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string GenerateJwtToken(int userId, string username)
        {
            string key = "MNU661B13T5rh6H52169abcdefghijklmnop";
            string duration = "60";

            var symmetricKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credentials = new SigningCredentials(symmetricKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim("id", userId.ToString()),
                new Claim("username", username)
            };

            var jwtToken = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToInt32(duration)),
                signingCredentials: credentials
            );

            string token = new JwtSecurityTokenHandler().WriteToken(jwtToken);

            return token;
        }
    }
}

