﻿namespace Hospital_Management.Models
{
    public class doctor
    {
        public int id { get; set; }
        public string img_source { get; set; }
        public string name { get; set; }
        public string _description { get; set; }
        public string speciality { get; set; }
    }
}
