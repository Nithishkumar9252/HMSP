﻿//using System.Data;
//using Microsoft.Data.SqlClient;

//namespace Hospital_Management.Models
//{
//    public class ViewRecordsResp
//    {
//        public List<Record> GetRecords(int patientId)
//        {
//            string connectionString = "Data Source =IN3339418W1; Initial Catalog=HMS; Integrated Security=true";
//            List<Record> records = new List<Record>();
//            using (SqlConnection connection = new SqlConnection(connectionString))
//            {
//                SqlCommand command = new SqlCommand("View_RecordsForUser", connection);
//                command.CommandType = CommandType.StoredProcedure;
//                connection.Open();
//                using (SqlDataReader reader = command.ExecuteReader())
//                {
//                    while (reader.Read())
//                    {
//                        Record record = new Record();
//                        record.RecordID = Convert.ToInt32(reader["RecordID"]);
//                        record.PatientID = Convert.ToInt32(reader["PatientID"]);
//                        record.DoctorName = reader["DoctorName"].ToString();
//                        record.CheckInDate = reader["CheckInDate"].ToString();
//                        record.Description = reader["_description"].ToString();
//                        records.Add(record);
//                    }
//                }
//            }
//        }
//       return records;
//        }

//}
        

