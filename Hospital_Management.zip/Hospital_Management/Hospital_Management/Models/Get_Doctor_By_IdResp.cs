﻿using Microsoft.Data.SqlClient;
using System.Data;

namespace Hospital_Management.Models
{
    public class Get_Doctor_By_IdResp
    {
        public IEnumerable<doctor> GetDoctorById(int id)
        {
            string connectionString = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";

            List<doctor> products = new List<doctor>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("select_doctor", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Id", id);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    doctor product = new doctor()
                    {
                        id = Convert.ToInt32(reader["id"]),
                        img_source = reader["img_source"].ToString(),
                        name = reader["name"].ToString(),
                        speciality = reader["speciality"].ToString(),
                        _description = reader["_description"].ToString()
                    };
                    products.Add(product);
                }
                reader.Close();
            }
            return products;
        }
    }
}
