﻿namespace Hospital_Management.Models
{
    public class LogMessageRequestResp
    {
        public string Message { get; set; }
    }
}
