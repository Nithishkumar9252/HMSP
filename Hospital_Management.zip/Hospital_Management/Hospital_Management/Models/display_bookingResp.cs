﻿using Microsoft.Data.SqlClient;

namespace Hospital_Management.Models
{
    public class display_bookingResp
    {
        public List<booking_list> GetList(int PatientID)
        {
            string connectionString = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
            // Create a connection to the database
            List<booking_list> bookings = new List<booking_list>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand("GetBookingDetails", connection))
            {
                // Set command type to stored procedure
                command.CommandType = System.Data.CommandType.StoredProcedure;

                // Add parameter for patient ID
                command.Parameters.Add(new SqlParameter("@PatientID", PatientID));

                // Open connection and execute command
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Read results and print them to the console
                while (reader.Read())
                {
                    booking_list b = new booking_list();
                    b.PatientName = (string)reader["PatientName"];
                    b.DoctorName = (string)reader["DoctorName"];
                    b.AppointmentDate = (string)reader["AppointmentDate"];
                    b.TimeSlot = (string)reader["TimeSlot"];
                    b.bookingID = Convert.ToInt32(reader["bookingID"]);
                    bookings.Add(b);
                }
                reader.Close();
                connection.Close();

                return bookings;
            }
        }
    }
}
