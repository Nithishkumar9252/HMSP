﻿using Microsoft.Data.SqlClient;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Hospital_Management.Models
{
    public class adminloginResp
    {
       
            public string adminlogins(adminlogin model)
            {
                string constr = "Server = IN3339418W1; Database = HMS; Trusted_Connection = SSPI; Encrypt = false; TrustServerCertificate = true";
                try
                {
                    using (SqlConnection conn = new SqlConnection(constr))
                    {
                        SqlCommand cmd = new SqlCommand("admin_login", conn);
                        cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@User_Name", SqlDbType.VarChar, 20).Value = model.Username;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar, 20).Value = model.password;

                    cmd.Parameters.AddWithValue("@Failed_Attempts", SqlDbType.Int).Direction = ParameterDirection.Output;
                     cmd.Parameters.AddWithValue("@Is_Locked", SqlDbType.Bit).Direction = ParameterDirection.Output;

                    SqlParameter returnValueParam = new SqlParameter("@ReturnValue", SqlDbType.Int);
                    returnValueParam.Direction = ParameterDirection.ReturnValue;
                    cmd.Parameters.Add(returnValueParam);

                    conn.Open();
                    cmd.ExecuteNonQuery();

                    int userId = (int)returnValueParam.Value;
                    bool isLocked = Convert.ToBoolean(cmd.Parameters["@Is_Locked"].Value);
                    int failedAttempts = Convert.ToInt32(cmd.Parameters["@Failed_Attempts"].Value);

                    if (userId == 0)
                    {
                        if (isLocked)
                            return "locked";
                        else
                            return "Incorrect";
                    }

                    return GenerateJwtToken(userId, model.Username);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private string GenerateJwtToken(int userId, string username)
        {
            string key = "MNU661B13T5rh6H52169abcdefghijklmnop";
            string duration = "60";

            var symmetricKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credentials = new SigningCredentials(symmetricKey, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim("id", userId.ToString()),
                new Claim("username", username)
            };

            var jwtToken = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims: claims,
                expires: DateTime.Now.AddMinutes(Convert.ToInt32(duration)),
                signingCredentials: credentials
            );

            string token = new JwtSecurityTokenHandler().WriteToken(jwtToken);

            return token;
        }
    }
}


