﻿////using System;
////using System.Data;
////using System.Data.SqlClient;
////using System.Threading.Tasks;

////namespace Hospital_Management.Repository
////{


////    public class UserRepository
////    {
////        private readonly string _connectionString;

////        public UserRepository(string connectionString)
////        {
////            _connectionString = connectionString;
////        }

////        public async Task<int?> SignUpOrLoginAsync(string firstName, string lastName, int age, string gender, string bloodGroup, string phone, string address, string email, string userName, string password, string action)
////        {
////            using (SqlConnection connection = new SqlConnection(_connectionString))
////            {
////                using (SqlCommand command = new SqlCommand("User_SignUpOrLogin", connection))
////                {
////                    command.CommandType = CommandType.StoredProcedure;

////                    // Parameters
////                    command.Parameters.AddWithValue("@FirstName", firstName);
////                    command.Parameters.AddWithValue("@LastName", lastName);
////                    command.Parameters.AddWithValue("@Age", age);
////                    command.Parameters.AddWithValue("@Gender", gender);
////                    command.Parameters.AddWithValue("@Blood_Group", bloodGroup);
////                    command.Parameters.AddWithValue("@Phone", phone);
////                    command.Parameters.AddWithValue("@Address", address);
////                    command.Parameters.AddWithValue("@Email", email);
////                    command.Parameters.AddWithValue("@User_Name", userName);
////                    command.Parameters.AddWithValue("@Password", password);
////                    command.Parameters.AddWithValue("@Action", action);

////                    // Output parameter
////                    SqlParameter outputParameter = new SqlParameter("@PatientId", SqlDbType.Int);
////                    outputParameter.Direction = ParameterDirection.Output;
////                    command.Parameters.Add(outputParameter);

////                    await connection.OpenAsync();
////                    await command.ExecuteNonQueryAsync();

////                    // Retrieve the output parameter value
////                    int? patientId = outputParameter.Value as int?;

////                    return patientId;
////                }
////            }
////        }
////    }

////}


//using System;
//using System.Data;

//using System.Threading.Tasks;
//using Microsoft.Data.SqlClient;

//public class UserRepository
//{
//    private readonly string _connectionString;

//    public UserRepository(string connectionString)
//    {
//        _connectionString = connectionString;
//    }

//    public async Task<int?> SignUpOrLoginAsync(string firstName, string lastName, int age, string gender, string bloodGroup, string phone, string address, string email, string userName, string password, string action)
//    {
//        using (SqlConnection connection = new SqlConnection(_connectionString))
//        {
//            using (SqlCommand command = new SqlCommand("User_SignUpOrLogin", connection))
//            {
//                command.CommandType = CommandType.StoredProcedure;

//                // Parameters
//                command.Parameters.AddWithValue("@FirstName", firstName);
//                command.Parameters.AddWithValue("@LastName", lastName);
//                command.Parameters.AddWithValue("@Age", age);
//                command.Parameters.AddWithValue("@Gender", gender);
//                command.Parameters.AddWithValue("@Blood_Group", bloodGroup);
//                command.Parameters.AddWithValue("@Phone", phone);
//                command.Parameters.AddWithValue("@Address", address);
//                command.Parameters.AddWithValue("@Email", email);
//                command.Parameters.AddWithValue("@User_Name", userName);
//                command.Parameters.AddWithValue("@Password", password);
//                command.Parameters.AddWithValue("@Action", action);

//                // Output parameter
//                SqlParameter outputParameter = new SqlParameter("@PatientId", SqlDbType.Int);
//                outputParameter.Direction = ParameterDirection.Output;
//                command.Parameters.Add(outputParameter);

//                await connection.OpenAsync();
//                await command.ExecuteNonQueryAsync();

//                // Retrieve the output parameter value
//                int? patientId = outputParameter.Value as int?;

//                return patientId;
//            }
//        }
//    }
//}
