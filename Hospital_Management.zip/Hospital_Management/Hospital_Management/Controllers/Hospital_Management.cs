﻿using Hospital_Management.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Serilog;

namespace Hospital_Management.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Hospital_Management : ControllerBase
    {
        //public Hospital_Management(UserRepository userRepository)
        //{
        //    _userRepository = userRepository;
        //}


        usersignupResp obj = new usersignupResp();
        [HttpPost]
        [Route("api/users/generate")]
        public int generate([FromBody] usersignup model)
        {
            return obj.addentry(model);
        }
        /// <summary>
        /// 
        /// </summary>
        userloginResp obj10 = new userloginResp();
        [HttpPost]
        [Route("api/users/validate")]
        public ActionResult loginadd(userlogin model)
        {
            return Ok(obj10.userlogins(model));
        }



        //UserRepository userRepository = new UserRepository();
        //[HttpPost("SignUp")]
        //public async Task<IActionResult> SignUp(UserDetails userDetails)
        //{
        //    try
        //    {
        //        int? userId = await userRepository.SignUpOrLoginAsync(
        //            userDetails.FirstName,
        //            userDetails.LastName,
        //            userDetails.Age,
        //            userDetails.Gender,
        //            userDetails.BloodGroup,
        //            userDetails.Phone,
        //            userDetails.Address,
        //            userDetails.Email,
        //            userDetails.UserName,
        //            userDetails.Password,
        //            action:"SignUp");

        //        if (userId.HasValue)
        //        {
        //            return Ok(userId);
        //        }
        //        else
        //        {
        //            return BadRequest("Failed to sign up.");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"An error occurred: {ex.Message}");
        //    }
        //}

        //[HttpPost("Login")]
        //public async Task<IActionResult> Login(LoginRequest loginRequest)
        //{
        //    try
        //    {
        //        int? userId = await userRepository.SignUpOrLoginAsync(
        //            firstName: "",
        //            lastName: "",
        //            age: 0,
        //            gender: "",
        //            bloodGroup: "",
        //            phone: "",
        //            address: "",
        //            email: "",
        //            loginRequest.UserName,
        //            loginRequest.Password,
        //            action: "Login");

        //        if (userId.HasValue)
        //        {
        //            return Ok(userId);
        //        }
        //        else
        //        {
        //            return BadRequest("Invalid username or password.");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return StatusCode(500, $"An error occurred: {ex.Message}");
        //    }
        //}



        //[HttpPost("signup")]
        //public async Task<IActionResult> SignUp(UserDetails userDetails)
        //{
        //    int? userId = await _userRepository.SignUpOrLoginAsync(userDetails.FirstName, userDetails.LastName, userDetails.Age, userDetails.Gender, userDetails.BloodGroup, userDetails.Phone, userDetails.Address, userDetails.Email, userDetails.UserName, userDetails.Password, "Signup");
        //    if (userId.HasValue)
        //    {
        //        return Ok($"User signed up successfully. UserID: {userId}");
        //    }
        //    else
        //    {
        //        return BadRequest("User with the provided email already exists.");
        //    }
        //}

        //[HttpPost("login")]
        //public async Task<IActionResult> Login(LoginRequest loginRequest)
        //{
        //    int? nullInt = null;
        //    int? userId = await _userRepository.SignUpOrLoginAsync(loginRequest.UserName, loginRequest.Password,null, null, null, null, null, null, null, null, "Login");
        //    if (userId.HasValue)
        //    {
        //        return Ok($"User logged in successfully. UserID: {userId}");
        //    }
        //    else
        //    {
        //        return BadRequest("Incorrect username or password.");
        //    }
        //}
    }


    //UserRepository UserRepo = new UserRepository();
    //[HttpPost("signup")]
    //public async Task<IActionResult> S(UserDetails userDetails)
    //{
    //    int? userId = await UserRepo.SignUpOrLoginAsync(userDetails.FirstName, userDetails.LastName, userDetails.Age, userDetails.Gender, userDetails.BloodGroup, userDetails.Phone, userDetails.Address, userDetails.Email, userDetails.UserName, userDetails.Password, "Signup");
    //    if (userId.HasValue)
    //    {
    //        return Ok($"User signed up successfully. UserID: {userId}");
    //    }
    //    else
    //    {
    //        return BadRequest("User with the provided email already exists.");
    //    }
    //}

    //[HttpPost("login")]
    //public async Task<IActionResult> Login(LoginRequest loginRequest)
    //{
    //    int? userId = await userRepository.SignUpOrLoginAsync(loginRequest.UserName, loginRequest.Password, null, null, null, null, null, null, null, null, "Login");
    //    if (userId.HasValue)
    //    {
    //        return Ok($"User logged in successfully. UserID: {userId}");
    //    }
    //    else
    //    {
    //        return BadRequest("Incorrect username or password.");
    //    }
    //}

    //admin_login ob=new admin_login();
    //[HttpPost]
    //[Route("api/user/validate")]
    //public IActionResult VerifyUser(userlogin user)
    //{
    //    if (user == null)
    //    {
    //        return BadRequest("User object is null.");
    //    }
    //    int userId;
    //    int failedAttempts;
    //    bool isLocked;

    //    ob.VerifyUserLogin(user, out userId, out failedAttempts, out isLocked);

    //    if (userId > 0)
    //    {
    //        // User verified successfully
    //        return Ok(new { UserId = userId, FailedAttempts = failedAttempts, IsLocked = isLocked });
    //    }
    //    else
    //    {
    //        // User verification failed
    //        return BadRequest("Invalid username or password.");
    //    }
    //}


    //adminsignupResp obj1= new adminsignupResp();
    //    [HttpPost]
    //    [Route("api/admin/generate")]
    //    public int generate_admin([FromBody] adminsignup model)
    //    {
    //        return obj1.addadminentry(model);
    //    }

    //    adminloginResp obj7 = new adminloginResp();
    //    [HttpPost]
    //    [Route("api/admins/validate")]
    //    public ActionResult adminadd(adminlogin model)
    //    {
    //        return Ok(obj7.adminlogins(model));
    //    }


    //    doctorsignupResp obj2=new doctorsignupResp();
    //    [HttpPost]
    //    [Route("api/doctor/generate")]
    //    public int generate_doctor([FromBody] doctorsignup model)
    //    {
    //        return obj2.adddoctorentry(model);
    //    }


    //    doctoraddResp obj3=new doctoraddResp();
    //    [HttpPost]
    //    [Route("api/users/generate/doctor")]
    //    public int generate_adddoctor([FromBody] doctor model)
    //    {
    //        model.img_source = "../../assets/images/" + model.img_source;
    //        return obj3.addentry(model);

    //    }

    //    doctordeleteResp obj4= new doctordeleteResp();
    //    [HttpDelete("api/users/delete/{doctorId}")]
    //    public string delete_doctor(int doctorID)

    //    {

    //        return obj4.Delete(doctorID);
    //    }

    //    all_bookingsResp obj5= new all_bookingsResp();


    //    [HttpGet]
    //    [Route("api/doctor/")]
    //    public IEnumerable<doctor> GetDoctor()
    //    {
    //        return obj5.GetDoctor();
    //    }

    //    appointmentResp obj6= new appointmentResp();
    //    [HttpPost]
    //    [Route("api/users/booking")]
    //    public ActionResult Bookings(Bookings model)
    //    {
    //        return Ok(obj6.booking(model));
    //    }




}

