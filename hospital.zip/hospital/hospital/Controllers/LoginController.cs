﻿using hospital.models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using SlackAPI;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Numerics;
using System.Security.Claims;
using System.Text;
using static System.Net.Mime.MediaTypeNames;

namespace hospital.Controllers
{
    [ApiController]
    public class LoginController : ControllerBase
    {
        logindetails obj10 = new logindetails();

        details obj = new details();
        [HttpPost]
        [Route("api/users/generate")]
        public int generate([FromBody] signup model)
        {
            return obj.addentry(model);
        }



        adminsignup obj1 = new adminsignup();
        [HttpPost]
        [Route("api/users/generate/admin")]
        public int generate_admin([FromBody] adminsignupmodel model)
        {
            return obj1.addadminentry(model);
        }


        doctoradd obj3 = new doctoradd();
        [HttpPost]
        [Route("api/users/generate/doctor")]
        public int generate_doctor([FromBody] Product model)

        {
            model.img_source = "../../assets/images/" + model.img_source;
            return obj3.addentry(model);
        }


        doctordelete docdel=new doctordelete();

       //demo*
       [HttpDelete("api/users/delete/{doctorId}")]
        public string delete_doctor(int doctorID)

        {
           
            return docdel.Delete(doctorID);
        }



        display_all_bookings disbooking= new display_all_bookings();
        [HttpGet]
        [Route("api/doctor/")]
       public IEnumerable<Product> GetProduct()
        {
            return disbooking.GetProducts();
        }


        [HttpPost]
        [Route("api/users/validate")]
        public ActionResult loginadd(login model)
        {
            return Ok(obj10.login(model));
        }



        logindetails token = new logindetails();

        adminlogin objnew = new adminlogin();


        [HttpPost]
        [Route("api/users/admin_validate")]
        public ActionResult adminloginadd(login model)
        {
            return Ok(objnew.adminlogins(model));
        }


        appointment objnew1 = new appointment();

        [HttpPost]
        [Route("api/users/booking")]
        public ActionResult bookings(bookings model)
        {
            return Ok(objnew1.booking(model));
        }





        Get_Doctor_By_Id getdoctor=new Get_Doctor_By_Id();

        [HttpGet]
        [Route("api/doctor/{id}")]
        public IEnumerable<Product> GetDoctorBy_Id(int id)
        {
            return getdoctor.GetDoctorById(id);
        }

        bookslot book=new bookslot();

        [HttpGet("api/slot/{CheckInDate}/{DoctorID}")]
        public List<string> bookSlot(string CheckInDate, int DoctorID)
        {
            return book.bookSlots(CheckInDate, DoctorID);
        }


        display_booking dispbooking=new display_booking();
        [HttpGet]
        [Route("api/admin/displaybooking/{PatientID}")]
        public List<booking> GetLists(int PatientID)
        {
            return dispbooking.GetList(PatientID);
        }

        delete_booking delete_Booking=new delete_booking(); 

        [HttpDelete("api/users/deleteBookings/{bookingID}")]
        public string DeleteBookings(int bookingID)
        {
            return delete_Booking.DeleteBookings(bookingID);    
        }



        display_total_bookings display_Total_Bookings=new display_total_bookings();

        [HttpGet]
        [Route("api/admin/displaytotalbooking")]
        public List<totalbookings> GetFullList()
        {
            return display_Total_Bookings.GetFullList();
        }

        [HttpPost]
        [Route("api/logs")]
        public IActionResult LogMessage([FromBody] LogMessageRequest request)
        {
            try
            {
                var filePath = @"C:\logs\imp.txt";
                var message = $"{DateTime.Now.ToString()} - {request.Message}\n";
                System.IO.File.AppendAllText(filePath, message);
                return Ok();
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }












    }

}