﻿using System.Data.SqlClient;

namespace hospital.models
{
    public class display_booking
    {
        public List<booking> GetList(int PatientID)
        {
            string connectionString = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";
            // Create a connection to the database
            List<booking> bookings = new List<booking>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand("GetBookingDetails", connection))
            {
                // Set command type to stored procedure
                command.CommandType = System.Data.CommandType.StoredProcedure;

                // Add parameter for patient ID
                command.Parameters.Add(new SqlParameter("@PatientID", PatientID));

                // Open connection and execute command
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Read results and print them to the console
                while (reader.Read())
                {
                    booking b = new booking();
                    b.PatientName = (string)reader["PatientName"];
                    b.DoctorName = (string)reader["DoctorName"];
                    b.AppointmentDate = (string)reader["AppointmentDate"];
                    b.TimeSlot = (string)reader["TimeSlot"];
                    b.bookingID = Convert.ToInt32(reader["bookingID"]);
                    bookings.Add(b);
                }
                reader.Close();
                connection.Close();

                return bookings;
            }
        }
    }
}
