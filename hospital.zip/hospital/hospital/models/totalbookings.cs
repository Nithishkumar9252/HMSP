﻿namespace hospital.models
{
    public class totalbookings
    {
        public string PatientName { get; set; }
        public string DoctorName { get; set; }
        public string AppointmentDate { get; set; }
        public string TimeSlot { get; set; }
        public int bookingID { get; set; }
        public int PatientID { get; set; }
    }
}
