﻿namespace hospital.models
{
    public class logging
    {

    }
}
