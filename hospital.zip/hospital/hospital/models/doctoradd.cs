﻿using System.Data.SqlClient;
using System.Data;

namespace hospital.models
{
    public class doctoradd
    {
        string constr = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";
        public int addentry(Product model)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("Insert_Doctor_Details", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@Name", model.name);
                    cmd.Parameters.AddWithValue("@img_source", model.img_source);
                    cmd.Parameters.AddWithValue("@description", model._description);
                    cmd.Parameters.AddWithValue("@specialty", model.specialty);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                return 1;
            }
            catch
            {
                throw;
            }
        }
    }
}
