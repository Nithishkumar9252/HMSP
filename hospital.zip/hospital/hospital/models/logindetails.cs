﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace hospital.models
{
    public class logindetails
    {


        string constr = "Data Source =IN3422272W1; Initial Catalog=hospital_management_final; Integrated Security=true";
        public string login(login model)
        {

            try
            {
                using (SqlConnection conn = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("verify_User", conn);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@User_Name", model.username);
                    cmd.Parameters.AddWithValue("@Password", model.password);

                    cmd.Parameters.AddWithValue("@Failed_Attempts", SqlDbType.Int).Direction = ParameterDirection.Output;
                    cmd.Parameters.AddWithValue("@Is_Locked", SqlDbType.Bit).Direction = ParameterDirection.Output;

                    SqlParameter p = new SqlParameter();
                    p.DbType = System.Data.DbType.Int32;
                    p.Direction = System.Data.ParameterDirection.ReturnValue;
                    cmd.Parameters.Add(p);
                    conn.Open();
                    cmd.ExecuteNonQuery();

                    int _PatientId = (int)p.Value;

                    bool isLocked = Convert.ToBoolean(cmd.Parameters["@Is_Locked"].Value);

                    int failedAttempts = Convert.ToInt32(cmd.Parameters["@Failed_Attempts"].Value);

                    if (_PatientId == 0)

                    {
                        if (isLocked)

                        {
                            return ("locked");
                        }
                        else
                        {
                            return ("Incorrect");
                        }
                    }
                    var a = _PatientId.ToString();
                    return (jwtoken(_PatientId,model.username));

                }
            }
            catch
            {
                throw;
            }
        }
        public string jwtoken(int LoginID,string username)
        {
            LoginResponse response = new LoginResponse();


            string key = "MNU661B13T5rh6H52169";
            string duration = "60";



            var symmetrickey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key));
            var credential = new SigningCredentials(symmetrickey, SecurityAlgorithms.HmacSha256);



            var claims = new[]  {
                             new Claim("id",LoginID.ToString()),
                             new Claim("username",username.ToString()),

                             };



            var jwtToken = new JwtSecurityToken(
            issuer: "localhost",
            audience: "localhost",
            claims: claims,
            expires: DateTime.Now.AddMinutes(Int32.Parse(duration)),
            signingCredentials: credential);




            string a = new JwtSecurityTokenHandler().WriteToken(jwtToken);



            return a;



        }
    }
}
