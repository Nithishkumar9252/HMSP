﻿namespace hospital.models
{
    public class LogMessageRequest
    {
        public string Message { get; set; }
    }
}
