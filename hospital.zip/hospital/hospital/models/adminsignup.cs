﻿using System.Data.SqlClient;
using System.Data;

namespace hospital.models
{
    public class adminsignup
    {

        string constr = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";
        public int addadminentry(adminsignupmodel model)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("Insert_Admin_Details", connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@FirstName", model.firstname);
                    cmd.Parameters.AddWithValue("@LastName", model.lastname);
                    cmd.Parameters.AddWithValue("@Phone", model.phone);
                    cmd.Parameters.AddWithValue("@Email", model.email);
                    cmd.Parameters.AddWithValue("@User_Name", model.username);
                    cmd.Parameters.AddWithValue("@Password", model.password);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                return 1;
            }
            catch
            {
                throw;
            }
        }

      
    }
}
