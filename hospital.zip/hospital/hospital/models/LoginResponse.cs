﻿namespace hospital.models
{
    public class LoginResponse
    {
        public string LoginId { get; set; }
        public string username { get; set; }
    }
}
