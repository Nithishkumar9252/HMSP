﻿namespace hospital.models
{
    public class Product
    {
        public int id { get; set; }
        public string img_source { get; set; }
        public string name { get; set; }
        public string _description { get; set; }
        public string specialty { get; set; }
    }
}
