﻿using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.Data.SqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace hospital.models
{



    public class details
    {


        string constr = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";


        public int addentry(signup model)
        {
            try
            {
                using(SqlConnection connection = new SqlConnection(constr))
                {
                    SqlCommand cmd = new SqlCommand("Insert_Patient_Details",connection);
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@FirstName", model.firstname);
                    cmd.Parameters.AddWithValue("@LastName", model.lastname);
                    cmd.Parameters.AddWithValue("@Age", model.age);
                    cmd.Parameters.AddWithValue("@Gender", model.gender);
                    cmd.Parameters.AddWithValue("@Blood_Group", model.bloodgroup);
                    cmd.Parameters.AddWithValue("@Phone", model.phone);
                    cmd.Parameters.AddWithValue("@Address", model.address);
                    cmd.Parameters.AddWithValue("@Email", model.email);
                    cmd.Parameters.AddWithValue("@User_Name", model.username);
                    cmd.Parameters.AddWithValue("@Password",model.password);

                    connection.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                }
                return 1;
            }
            catch {
                throw;            
            }
        }

    }
}


