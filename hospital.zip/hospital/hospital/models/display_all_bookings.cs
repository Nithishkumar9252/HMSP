﻿using System.Data.SqlClient;
using System.Data;

namespace hospital.models
{
    public class display_all_bookings
    {
        public IEnumerable<Product> GetProducts()
        {
            string connectionString = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";
            List<Product> products = new List<Product>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("select_all_bookings", connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    Product product = new Product()
                    {
                        id = Convert.ToInt32(reader["id"]),
                        img_source = reader["img_source"].ToString(),
                        name = reader["name"].ToString(),
                        specialty = reader["specialty"].ToString(),
                        _description = reader["_description"].ToString()
                    };
                    products.Add(product);
                }
                reader.Close();
            }
            return products;
        }
    }
}
