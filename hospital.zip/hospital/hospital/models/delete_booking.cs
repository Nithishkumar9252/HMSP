﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;

namespace hospital.models
{
    public class delete_booking
    {

        public string DeleteBookings(int bookingID)
        {
            // Create a new SqlConnection object with your connection string
            string connectionString = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Create a SQL command that calls the DeleteDoctorAndBookings stored procedure
                SqlCommand command = new SqlCommand("delete_booking", connection);
                command.CommandType = CommandType.StoredProcedure;
                // Add the DoctorId parameter to the command
                command.Parameters.AddWithValue("@bookingID", bookingID);

                
                    // Open the connection
                    connection.Open();

                    // Execute the command
                    command.ExecuteNonQuery();

                // Return HTTP 200 (OK) response
                return "1";
                
            }
        }

    }
}
