﻿using System.Data.SqlClient;

namespace hospital.models
{
    public class appointment
    {


        public int booking(bookings book)
        {



            string connectionString = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";

            // Create a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                // Open the connection
                connection.Open();
                //SqlCommand updatewquantityCommand = new SqlCommand("update room set status='unavailable' where roomno=@rno", connection);
                //updatewquantityCommand.Parameters.AddWithValue("@rno", book.DoctorID);



                //updatewquantityCommand.ExecuteNonQuery();






                List<string> timeSlots = new List<string>();

                SqlCommand cmd = new SqlCommand("Select TimeSlot from Bookings where CheckInDate=@CheckInDate AND TimeSlot=@TimeSlot AND DoctorID=@DoctorID", connection);
                cmd.Parameters.AddWithValue("@CheckInDate",book.CheckInDate);
                cmd.Parameters.AddWithValue("@TimeSlot", book.TimeSlot);
                cmd.Parameters.AddWithValue("@DoctorID", book.DoctorID);
                int count = 0;
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        count += 1;
                        string timeSlot = reader["TimeSlot"].ToString();
                        timeSlots.Add(timeSlot);
                    }
                }
                if (count >= 1)
                {
                    connection.Close();
                    return (0);
                }
                else
                {

                    // Create a SQL command to insert the booking
                    SqlCommand command = new SqlCommand("INSERT INTO Bookings (PatientID, DoctorID, CheckInDate,TimeSlot) VALUES (@UserID, @DoctorID, @CheckInDate,@TimeSlot)", connection);



                    // Set the parameter values from the form data
                    command.Parameters.AddWithValue("@UserID", book.PatientID);
                    command.Parameters.AddWithValue("@DoctorID", book.DoctorID);
                    command.Parameters.AddWithValue("@CheckInDate", book.CheckInDate);
                    command.Parameters.AddWithValue("@TimeSlot", book.TimeSlot);


                    // Execute the SQL command to insert the booking
                    command.ExecuteNonQuery();
                    connection.Close();
                    return (1);
                }

                


               

             

            }
           
            // Close the connection
            
        }




    }



}

