﻿namespace hospital.models
{
    public class login
    {
        public int LoginID { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}
