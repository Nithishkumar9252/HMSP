﻿using System.Data.SqlClient;

namespace hospital.models
{
    public class display_total_bookings
    {

        public List<totalbookings> GetFullList()
        {
            string connectionString = "Data Source=IN3422272W1;Initial Catalog=hospital_management_final;Integrated Security=true";
            // Create a connection to the database
            List<totalbookings> bookings = new List<totalbookings>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand("totalbookings", connection))
            {
                // Set command type to stored procedure
                command.CommandType = System.Data.CommandType.StoredProcedure;

                // Add parameter for patient ID

                // Open connection and execute command
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                // Read results and print them to the console
                while (reader.Read())
                {
                    totalbookings b = new totalbookings();
                    b.PatientName = (string)reader["PatientName"];
                    b.DoctorName = (string)reader["DoctorName"];
                    b.AppointmentDate = (string)reader["CheckInDate"];
                    b.TimeSlot = (string)reader["TimeSlot"];
                    b.bookingID = Convert.ToInt32(reader["BookingID"]);
                    b.PatientID = Convert.ToInt32(reader["PatientID"]);
                    bookings.Add(b);
                }
                reader.Close();
                connection.Close();

                return bookings;
            }
        }
    }
}
